==================================================================================
BUILD OUTPUT DESCRIPTION
==================================================================================

========================
PLEASE USE JDK 15 OR UP 
========================


To run the project from the command line, go to the dist folder and
type the following:

java -jar "<NAME-OF-FILE>.jar" 
